import java.io.*;
/**
 * class CarOwner - write a description of the class here
 *
 * @author Adam Sanchez
 * @version v1.0 (12/8/2022)
 */
public class CarOwner extends Citizen implements CarOwnerInterface, Serializable
{
    private String license;
    private int month;
    private int year;

    
    /**
     * default constructor for CarOwner
     */
    public CarOwner(){
    super();
    license = "Not Assigned";
    month = 0;
    year = 0;    
    }
    
    /**
     * constructor for CarOwner
     * @param inFirstName - the first name being input
     * @param inLastName - the last name being input
     * @param inLicense - input license
     * @return inMonth - input month
     * @param inYear - input year
     */
    public CarOwner(String inFirstName, String inLastName, String inLicense, int inMonth, int inYear){
    super(inFirstName, inLastName);
    license = inLicense;
    month = inMonth;
    year = inYear;
    }
    
    /**
     * sets the license using the inputed license input
     * @param inLicense - the license number being input
     */
    public void setLicense(String inLicense){
        license = inLicense;
    }

    /**
     * grabs the license number and returns it
     * @return license
     */
    public String getLicense(){
        return license;
    }

    /**
     * sets the month for using the month being input
     * @param inMonth - the month being input
     */
    public void setmonth(int inMonth){
        month = inMonth;
    }

    /**
     * gets the month and returns it
     * @return month
     */
    public int getMonth(){
        return month;
    }

    /**
     * setter for the year using the year being input
     * @param inYear - the year being input
     */
    public void setYear(int inYear){
        year = inYear;
    }

    /**
     * gets the year and returns it
     */
    public int getYear(){
        return year;
    }

    /** 
     * overrides compareTo to sort CarOwners based on chronological 
     * of month and year car was last.  If param is null or not CarOwner 
    class, returns -1 
     * if object total months < param total months, temp is -1, object total 
    months > param total months, temp is 1 
     * otherwise the same and temp is 0 
     * @param o
     * @return temp 
     */ 
    public int compareTo(Object o){ 
        int temp = -1; 
        if(o != null && this.getClass() == o.getClass()){ 
            CarOwner copy = (CarOwner)o; 
            if((year*12+this.month) < (copy.year*12+copy.month)) 
                temp = -1; 
            else if ((year*12+this.month) > (copy.year*12+copy.month)) 
                temp = 1; 
            else //the same 
                temp = 0; 
        } 
        return temp; 
    } 

    /**
     * returns the information in string format
     */
    public String toString(){
        String date = month + "/" + year;
        String formatstr = "%-20s %10s %10s";
        return String.format(formatstr,super.toString(), license, date);
    }
}
