
/**
 * interface for the Car Owner 
 *
 * @author Adam Sanchez
 * @version v1.0 (12/8/2022)
 */
public interface CarOwnerInterface extends Comparable
{
    /**
     * sets the license using the inputed license input
     * @param inLicense - the license number being input
     */
    void setLicense(String inLicense);

    /**
     * grabs the license number and returns it
     */
    String getLicense();

    /**
     * sets the month for using the month being input
     * @param inMonth - the month being input
     */
    void setmonth(int inMonth);

    /**
     * gets the month and returns it
     */
    int getMonth();

    /**
     * setter for the year using the year being input
     * @param inYear- the year being input
     */
    void setYear(int inYear);

    /**
     * gets the year and returns it
     */
    int getYear();

    /**
     * compares one object to the object in the parameter and returns
     * @param o - the secondary object being input
     */
    int compareTo(Object o);

    /**
     * returns the information in string format
     */
    String toString();
}
