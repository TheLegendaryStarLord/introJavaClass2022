import java.io.Serializable;

/**
 * implements the citizen interface and sets the names for citizens
 *
 * @author Adam Sanchez
 * @version v1.0 (12/8/2022)
 */
abstract class Citizen implements CitizenInterface, Serializable
{
    private String firstName;
    private String lastName;

    /**
     * default constructor for Citizen
     */
    public Citizen(){
        firstName = "No Name";
        lastName = "No Name";
    }

    /**
     * constructor for Citizen
     * @param inFirstName - the first name being input
     * @param inLastName - the last name being input
     */
    public Citizen(String inFirstName, String inLastName){
        firstName = inFirstName;
        lastName = inLastName;
    }

    /**
     * setter for the first name of the citizen
     * @param inFirst - the first name being input
     */
    public void setFirstName(String inFirst){
        firstName = inFirst;
    }

    /**
     * getter for the first name and returns the name
     * @return firstName
     */
    public String getFirstName(){
        return firstName;
    }

    /**
     * setter for the Last name of the citizen
     * @param inLast - the last name being input
     */
    public void setLastName(String inLast){
        lastName = inLast;
    }

    /**
     * gets the last name and returns it
     * @return lastName
     */
    public String getLastName(){
        return lastName;
    }

    /**
     * information returns in string format
     * @returns the first and last name of citizen
     */
    public String toString(){
        return firstName + " " + lastName;
    }
}
