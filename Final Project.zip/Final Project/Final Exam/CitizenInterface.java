
/**
 * interface for the citizen class
 *
 * @author Adam Sanchez
 * @version v1.0 (12/8/2022)
 */
public interface CitizenInterface
{
    /**
     * setter for the first name of the citizen
     * @param inFirst - the first name being input
     */
    void setFirstName(String inFirst);

    /**
     * getter for the first name and returns the name
     */
    String getFirstName();

    /**
     * setter for the Last name of the citizen
     * @param inLast - the last name being input
     */
    void setLastName(String inLast);

    /**
     * gets the last name and returns it
     */
    String getLastName();

    /**
     * information returns in string format
     */
    String toString();
}
