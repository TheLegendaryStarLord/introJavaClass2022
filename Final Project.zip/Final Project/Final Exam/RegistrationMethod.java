import java.util.ArrayList;
import java.util.*;
import java.io.*;

/**
 * Write a description of class RegistrationMethod here.
 *
 * @author Adam Sanchez
 * @version v1.0 (12/8/2022)
 */
public class RegistrationMethod implements RegistrationMethodsInterface
{
    public final int REG_MONTH = 4;
    public final int REG_YEAR = 2022;
    String inputFileName;
    String outputFileName;
    String binFileName;

    /**
     * Prompts the user to provide the location of the csv file to be processed 
     * (registration.csv), the location for where the user wants the output file 
     * saved (output.txt), and the location for the binary file (ltStateBinary.dat).
     */
    public void setFileNames() throws FileNotFoundException {
        boolean FileFound = true;
        boolean outFileExists = true;
        boolean binfileExists = true;

        Scanner keyboard = new Scanner(System.in);
        //String inInputFile = "Initialization";

        do{
            System.out.println("Please enter the path to the registration file (c:/tmp/registration.csv): ");
            String inInputFileTest = keyboard.nextLine();
            try{
                Scanner inFileTest = new Scanner(new File(inInputFileTest));
                //Scanner inFileTest = new Scanner(inInputFile);
                FileFound = true;
                inFileTest.close();

            }
            catch(FileNotFoundException ex){
                System.out.println("File not found, please re-enter file path:");
            }

            inputFileName = inInputFileTest;
        }while (FileFound == false);

        //inputFileName = inInputFile;

        do{
            System.out.println("Please enter the path to the output file (i.e c:/tmp/output.txt): ");
            String inOutputFileTest = keyboard.nextLine();
            File outputFileTest = new File(inOutputFileTest);
            if (outputFileTest.exists()){
                System.out.println("the file \"" + outputFileTest + "\" already exists");
                outFileExists = true;
            }
            else{
                outFileExists = false;
                outputFileName = inOutputFileTest;
                System.out.println("output file path set");
            }
        }while(outFileExists);

        do{
            System.out.println("Please enter the path to the binFileTest (i.e c:/tmp/binFile.dat): ");
            String inBinFileTest = keyboard.nextLine();
            File binfileTest = new File(inBinFileTest);
            if (binfileTest.exists()){
                System.out.println("the file \"" + binfileTest+ "\" already exists");
                binfileExists = true;
            }
            else{
                binfileExists = false;
                binFileName = inBinFileTest;
                System.out.println("output file path set");
            }
        }while(binfileExists);

    }

    /**
     * Takes csv file (inputFileName) and parses out each record.  split() and nextLine() 
     * will be helpful.  For each line, create a CarOwner object and add to ArrayList <CarOwner>
     * collection
     * @param inList - Input list that has objects added to it
     */
    public void processTextToArrayList(ArrayList<CarOwner> inList){
        File inFile = new File(inputFileName);

        try(Scanner inputStream = new Scanner(inFile);){
            //Scanner inputStream = new Scanner(inFile);
            String headerLine = inputStream.nextLine();

            while (inputStream.hasNextLine()){
                String line = inputStream.nextLine();
                String[] arrayLine = line.split(",");
                CarOwner carOwner = new CarOwner(arrayLine[1],arrayLine[0],arrayLine[2], Integer.parseInt(arrayLine[3]), Integer.parseInt(arrayLine[4]));
                inList.add(carOwner);
            }

            inputStream.close();
        }
        catch(FileNotFoundException ex){
            System.out.println("File not found, please re-enter file path:");
        }       
    }

    /**
     * Prints out ArrayList passed in based on toString() along with passed in
     * message
     *
     * @param inList ArrayList<CarOwner> collection passed in to be written to
     * a text file
     * @param inMsg Message specific to the array being printed
     * @param inList - list of CarOwners
     * @param inMsg - the header before car owners are shown
     */
    public void printArrayListToFile(ArrayList<CarOwner> inList, String inMsg) throws IOException{
        FileWriter outputWrite = null;
        PrintWriter outputPrint = null;//may work save for later if does

        try{
            outputWrite = new FileWriter(outputFileName, true);//delete after testign
            //outputFileName
            outputPrint = new PrintWriter(outputWrite, true);
            outputPrint.println(inMsg);
            for(CarOwner carOwners: inList){
                outputPrint.println(carOwners);
                
            }
        }
        catch (IOException e){
            System.out.println("Error: file could not be written to");
        }
        finally{
            outputPrint.close();
            outputWrite.close();
        }
    }

    /**
     * Takes a ArrayList <CarOwner> collection as an input and creates a binary file output.  
     * The output file can later be read into the java program for processing.
     * 
     * @param inList ArrayList<CarOwner> collection
     */
    public void writeListToBinary(ArrayList<CarOwner> inList) throws IOException, FileNotFoundException{
        try{
            FileOutputStream binStream = new FileOutputStream(binFileName);
            ObjectOutputStream binObjStream = new ObjectOutputStream(binStream);
            binObjStream.writeObject(inList);

            binObjStream.close();
        }catch(FileNotFoundException ex){
            System.out.println("FileNotFoundException hit:");
        }
        catch(IOException e){
            System.out.println("IOException hit:");
        }

    }

    /**
     * Reads an ArrayList<CarOwner> collection from a binary file (ltStateBinary.dat).  
     * Then, each ArrayList object item is then written to a newly created CarOwner[], 
     * called temp.  temp is returned to the calling method.
     * @return list - list of CarOwners from binary file
     */
    public CarOwner[] readListFromBinary(){
        ArrayList<CarOwner> temp = new ArrayList<CarOwner>();

        try{
            FileInputStream binInStream = new FileInputStream(binFileName);
            ObjectInputStream binObjStream = new ObjectInputStream(binInStream);
            ArrayList<CarOwner> object = (ArrayList<CarOwner>) binObjStream.readObject();
            binObjStream.close();

            temp = (ArrayList<CarOwner>) object.clone();
        }
        catch(FileNotFoundException e){
            System.out.println("FileNotFoundException");
        }
        catch(IOException ex){
            System.out.println("IOException");
        }
        catch(ClassNotFoundException exc){
            System.out.println("ClassNotFoundException");
        }

        CarOwner[] list = new CarOwner[temp.size()];

        for(int i = 0; i < temp.size();i++){
            list[i] = temp.get(i);
        }

        return list;
    }

    /**
     * Prints out array passed in based on toString() along with passed in
     * message
     *
     * @param inArray CarOwner[] array to be written to a text file
     * @param inMsg Message specific to the array being printed
     */
    public void printArrayToFile(CarOwner[] inArray, String inMsg){
        File arrayToFile = new File(outputFileName);
        try{
            PrintWriter printArray = new PrintWriter(new FileWriter(arrayToFile, true));
            printArray.println("\n" + inMsg);
            for (int i = 0; i < inArray.length ;i++){
                printArray.println(inArray[i].toString());
            }
            printArray.close();
        }catch(IOException e){
            System.out.println("IOException");
        }
    }

    /**
     * Method that generates and returns an array for vehicles whose
     * registration have expired defined as registration is over 12 months old
     * based on current REG_MONTH and REG_YEAR.
     *
     * @param inArray CarOwner[]
     * @return overdueCarOwner - list of overdue car owners
     */
    public CarOwner[] flagOverdueOwners(CarOwner[] inArray){
        int monthsTotal = REG_YEAR*12 + REG_MONTH;
        int monthsOf = 0;
        int counter = 0;
        for(int i = 0; i < inArray.length ; i++){
            monthsOf = monthsTotal - (inArray[i].getYear()*12+inArray[i].getMonth());
            if (monthsOf > 12){
                counter++;
            }
        }
        CarOwner[] overdueCarOwner = new CarOwner[counter];
        int indexOf = 0;
        for (int i = 0; i < inArray.length ; i++){
            monthsOf = monthsTotal - (inArray[i].getYear()*12+inArray[i].getMonth());
            if (monthsOf > 12){                
                overdueCarOwner[indexOf++]=inArray[i];
            }
        }
        return overdueCarOwner;
    }

    /**
     * Method that generates and returns an array for vehicles whose
     * registration will expire in three months or less. The state of Looney
     * Tunes sends a reminder three months out to the car owner.
     *
     * @param inArray CarOwner[]
     * @return nearOverdue - a list of near overdue car owners
     */
    public CarOwner[] flagAlmostDueOwners(CarOwner[] inArray){
        int monthsTotal = REG_YEAR*12 + REG_MONTH;
        int monthsOf = 0;
        int counter = 0;
        for(int i = 0; i < inArray.length ; i++){
            monthsOf = monthsTotal - (inArray[i].getYear()*12+inArray[i].getMonth());
            if (monthsOf > 9 && monthsOf <= 12){
                counter++;
            }
        }
        CarOwner[] nearOverdue= new CarOwner[counter];
        int indexOf = 0;
        for (int i = 0; i < inArray.length ; i++){
            monthsOf = monthsTotal - (inArray[i].getYear()*12+inArray[i].getMonth());
            if (monthsOf > 9 && monthsOf <= 12){                
                nearOverdue[indexOf++]=inArray[i];
            }
        }
        return nearOverdue;
    }

}
