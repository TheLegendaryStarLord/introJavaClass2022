import java.io.*;
import java.util.*;

/**
 * reads the information of a Csv file and sorts the information for overdue car owners
 *
 * @author Adam Sanchez
 * @version v1.0 (12/10/2022)
 */
public class RegDemo
{
    public static void main(String[] args) throws IOException, FileNotFoundException {
        RegistrationMethod dmv = new RegistrationMethod();
        dmv.setFileNames();
        ArrayList<CarOwner> itState = new ArrayList<CarOwner>();
        dmv.processTextToArrayList(itState);        
        dmv.printArrayListToFile(itState,"Initial Set of Car Owners - Unsorted");
        dmv.writeListToBinary(itState);
        CarOwner[] itStateCopy = dmv.readListFromBinary();
        Arrays.sort(itStateCopy);        
        dmv.printArrayToFile(itStateCopy, "Sorted list based on Registration date");
        CarOwner[] overdue = dmv.flagOverdueOwners(itStateCopy);
        dmv.printArrayToFile(overdue, "Owners with Expired Registration");
        CarOwner[] almostDue = dmv.flagAlmostDueOwners(itStateCopy);
        dmv.printArrayToFile(almostDue, "Owners with registration expiring in three months or less");
        
    }
}
