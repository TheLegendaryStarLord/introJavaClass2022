import java.util.Arrays;

/**
 * ArrayMethods class does the following:
 * 1) Setup an array with preset values.
 * 2) counts the length of the array, the sum, and the average
 * 3) finds the max value's index, all occurances of a value
 * 4) creates a seperate copy of the array and reorganizes it in seperate ways.
 * 
 * @author Adam Sanchez
 * @version v1.1
 * @since 11/1/22 (v1.1)
 */

public class ArrayMethods {
  private final int[] a = { 7, 8, 8, 3, 4, 9, 8, 7 };

  /**
   * count() - counts the length of the array
   * 
   * @return ArrayLength - the length of the array
   */
  public int count() {
    int ArrayLength = a.length;
    return ArrayLength;
  }

  /**
   * sum() - calculates the sum of all numbers in the array
   * 
   * @return total - the sum total of all the values
   */
  public int sum() {
    int total = 0;
    for (int i = 0; i < a.length; i++) {
      total += a[i];
    }
    return total;
  }

  /**
   * average() - calculates the average of the array
   * 
   * @return DblSum / DblCount - the average of the array
   */
  public double average() {
    double DblSum = sum(), DblCount = count();
    return DblSum / DblCount;
  }

  /**
   * findMax() - finds the max value of the array
   * 
   * @return Max - the max value fo the array
   */
  public int findMax() {
    int Max = a[0];
    for (int i = 1; i < a.length; i++) {
      if (a[i] > Max)
        Max = a[i];
    }
    return Max;
  }

  /**
   * findIndexOfMax() - finds the index of the max value of the array
   * 
   * @return MaxIndex - the index of the max value fo the array
   */
  public int findIndexOfMax() {
    int MaxIndex = 0;
    boolean foundstatus = false;
    int Index = 0;
    int MaxValue = findMax();

    while (!foundstatus && Index < a.length) {
      if (a[Index] == MaxValue) {
        foundstatus = true;
        MaxIndex = Index;
      }
      Index++;
    }
    return MaxIndex;
  }

  /**
   * findLast() - finds the last of a value of the array
   * 
   * @param key - the value being used
   * @return LastIndex - the index of the last of a value
   */
  public int findLast(int key) {
    int LastIndex = a.length - 1;
    boolean FoundLastOf = false;
    while (!FoundLastOf) {
      for (int i = 0; i <= a.length - 1; i++) {
        if (a[i] == key) {
          LastIndex = i;
          FoundLastOf = true;
        } else if (!FoundLastOf) {
          LastIndex = -1;
          FoundLastOf = true;
        }
      }
    }
    return LastIndex;

  }

  /**
   * findAll() - searchs for all instances of a value
   * 
   * @param key - the value being searched for
   * @return IndexContainer - a new array containing all of the indexes of the key
   */
  public int[] findAll(int key) {
    int Occurance = 0;
    int IndexOfOccurance = 0;
    int IndexCounter = 0;
    for (int i = 0; i < a.length; i++) {
      if (a[i] == key) {
        Occurance++;
      }
    }
    int[] IndexContainer = new int[Occurance];
    for (int i = 0; i < a.length; i++) {
      if (a[i] == key) {
        IndexContainer[IndexCounter++] = i;
      }
    }
    return IndexContainer;
  }

  /**
   * getArray() - gets the array
   *
   * @return a - the array being grabbed
   */
  public int[] getArray() {
    return a;
  }

  /**
   * copyArray() - copies the array
   *
   * @return newArray - the copy of the Array
   */
  public int[] copyArray() {
    int[] newArray = Arrays.copyOf(a, a.length);
    return newArray;
  }

  /**
   * prints an int array, nicely formatted
   * 
   * @param a[ ] int array to print
   */
  public void print(int a[]) {
    System.out.print("{");
    int i;
    // print elements before the last, separated by commas
    for (i = 0; i < a.length - 1; ++i)
      System.out.print(a[i] + ", ");
    // print last element. Careful here to handle length 0
    if (a.length > 0)
      System.out.print(a[i]);
    System.out.println("}");
  }

  /**
   * sortArray() - sorts the array by lowest to highest
   * 
   * @param inArray - the array being sorted
   */
  public void sortArray(int[] inArray) {
    int StartScan, index, minIndex, minValue;
    for (StartScan = 0; StartScan < (inArray.length-1); StartScan++){
      minIndex = StartScan;
      minValue = inArray[StartScan];
      for (index = StartScan+1; index < inArray.length; index++){
        if(inArray[index] < minValue){
          minValue = inArray[index];
          minIndex = index;
        }
      }
      inArray[minIndex] = inArray[StartScan];
      inArray[StartScan] = minValue;
    }
  }

  /**
   * reverseArray() - reverses the array
   * 
   * @param inArray - the array being reversed
   */
  public void reverseArray(int[] inArray) {
    int t;
    for (int i = 0; i < inArray.length / 2; i++) {
      t = inArray[i];
      inArray[i] = inArray[inArray.length - i - 1];
      inArray[inArray.length - i - 1] = t;
    }
  }

  /**
   * genFiveByFiveRows() - generates int[5][5] and then prints int[ ][ ]
   * 
   */
  public void genFiveByFiveRows() {
    int[][] FivebyFiveInt = new int[5][5];
    int ArrayFiller=0;
    System.out.println("  A B C D E");

    for (int row = 0; row < FivebyFiveInt.length; row++){
      ArrayFiller++;
      for (int col = 0; col < FivebyFiveInt[row].length; col++){
        FivebyFiveInt[row][col]=ArrayFiller;
      }
    }


    
    for (int row = 0; row < FivebyFiveInt.length; row++) {
      System.out.print(row + 1 + " ");
      for (int col = 0; col < FivebyFiveInt[row].length; col++) {
        System.out.print(FivebyFiveInt[row][col] + " ");
      }
      System.out.println();
    }
  }

  /**
   * genFiveByFiveCols() - generates char[5][5] and then prints char[ ][ ]
   * 
   */
  public void genFiveByFiveCols() {

    char[][] FivebyFiveChar = new char[5][5];
    char CharArrayFiller;

    for (int row = 0; row < FivebyFiveChar.length; row++){
      CharArrayFiller='A';
      for (int col = 0; col < FivebyFiveChar[row].length; col++){
        FivebyFiveChar[row][col]=CharArrayFiller++;
      }
    }


    
    System.out.println("  A B C D E");
    for (int row = 0; row < FivebyFiveChar.length; row++) {
      System.out.print(row + 1 + " ");
      for (int col = 0; col < FivebyFiveChar[row].length; col++) {
        System.out.print(FivebyFiveChar[row][col] + " ");
      }
      System.out.println();
    }

  }
}