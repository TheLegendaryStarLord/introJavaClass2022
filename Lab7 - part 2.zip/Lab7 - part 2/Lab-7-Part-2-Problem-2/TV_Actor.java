/**
 * BankAccount class does the following:
 * 1) Connects to Main.java
 * 2) sets up names and shows to add to ArrayList list
 * 
 * @author Adam Sanchez
 * @version v1.0
 * @since 11/2/22 (v1.0)
 */

public class TV_Actor {
  private String Name;
  private String Show;

  /**
   * TV_Actor() - The default data being used for Name and Show
   */
  public TV_Actor() {
    Name = "Unknown Actor";
    Show = "Unkown Show";

  }

  /**
   * TV_Actor() - Input changes to Name and Show
   * 
   * @param inName - new actor name
   * @param inShow - new show name
   */
  public TV_Actor(String inName, String inShow) {
    Name = inName;
    Show = inShow;
  }

  /**
   * setShow() - sets a new show name
   * 
   * @param newShow - new show name
   */
  public void setShow(String newShow) {
    this.Show = newShow;
  }

  /**
   * setActor() - sets a new actor name
   * 
   * @param newActor - new actor name
   */
  public void setActor(String newActor) {
    this.Name = newActor;
  }

  /**
   * getShow() - gets the name of the show
   * 
   * @return Show - name of the show
   */
  public String getShow() {
    return Show;
  }

  /**
   * getActor() - gets the actor name
   * 
   * @return Name - Name of the actor
   */
  public String getActor() {
    return Name;
  }

  /**
   * toString() - prints out the name and show
   * Code to print out a TV_Actor object
   * put in TV_Actor class file, this overrides the default .toString()
   * 
   * @return output formatted TV_Actor output
   */
  public String toString() {
    String output = "Name: " + Name + ", Show: " + Show;
    return output;
  }

}