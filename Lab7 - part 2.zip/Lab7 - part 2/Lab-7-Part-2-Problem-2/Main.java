import java.util.ArrayList;

/**
 * Write a description of class TV_ActorDemo here.
 * 1) Connects to TV_Actor
 * 2) Sets up the name of actor and show
 * 3) Displays the name of actor and show 
 * @author Adam Sanchez
 * @version v1.0
 * @since 11/2/2022
 */
public class Main { // Change to Main in Replit and rename file to Main.java
  // write out main()
  public static void main(String[] args) {
    ArrayList<TV_Actor> list = new ArrayList<TV_Actor>();
    list.add(new TV_Actor("Bart", "The Simpsons"));
    list.add(new TV_Actor("Maggie", "The Simpsons"));
    list.add(new TV_Actor("Lisa", "The Simpsons"));
    printArrayList(list);
    list.remove(1);
    printArrayList(list);
    list.set(1, new TV_Actor("Butthead", "B&B"));
    printArrayList(list);
    list.add(1, new TV_Actor("Beavis", "B&B"));
    printArrayList(list);
    list.remove(0);
    printArrayList(list);
  }// end main()

  public static void printArrayList(ArrayList<TV_Actor> inList) {
    System.out.println("Printing ArrayList<TV_Actor> list");
    int actorNumber = 0;
    for (TV_Actor entry : inList) {
      System.out.println("Actor " + actorNumber + " " + entry);
      actorNumber++;
    }
    System.out.println();
  }// end printArrayList
}// end TCV_ActorDemo