import javax.swing.JOptionPane;
import java.util.Scanner;
import java.io.*; //Note - Since we are using multiple classes from java.io, we can use the * wildcard vs listing each individually.  Any 2+, it is best to use *

/**
 * Grades class does the following:
 * 1) recieves input from a seperate file
 * 2) calculates from File and counts how many of each grade there are
 * 3) gives user output file with data collected from input of grade
 * 
 * @author Adam Sanchez
 * @version v1.1
 * @since 10/6/22 (v1.1)
 */
public class Main { // Change to Main
  public static void main(String[] args) throws IOException {
    String inFile, outFile;
    inFile = getInFile();
    outFile = getOutFile();
    processFile(inFile, outFile);
    System.exit(0);
  }// end main

  /**
   * Uses JOptionPane to get and return input file name
   * 
   * @return name of file from JOptionPane //NOTE - Description only for return
   */
  public static String getInFile() throws IOException {
    String inFileString;
    inFileString = JOptionPane.showInputDialog("Enter the name of the input file (ie input.txt)");
    File file = new File(inFileString);
    while (!file.exists()) {
      inFileString = JOptionPane.showInputDialog("Enter the name of the input file (ie input.txt)");
      file = new File(inFileString);
    }
    return inFileString;
  }

/**
 * uses JOption to get and return output file name
 * 
 * @return - Gives output file name
 */
  public static String getOutFile() {
    String outputFileName = JOptionPane.showInputDialog("output file name: ");
    return outputFileName;
  }

/**
 * Processes input for grades
 * 
 * @param inFileName - input file name to get data
 * @param inOutFile  - output file name to place data
 */
  public static void processFile(String inFileName, String inOutFile) throws IOException {
    //// vars section
    int number;
    int A, B, C, D, F, min, max;
    int total, count;
    double avg;
    int sets = 1;
    //// Scanner and PrintWriter streams section
    File inputName = new File(inFileName);
    Scanner inputStream = new Scanner(inputName);
    PrintWriter outputStream = new PrintWriter(inOutFile);
    while (inputStream.hasNext()) {
      A = B = C = D = F = count = 0;
      avg = 0.0;
      number = inputStream.nextInt();
      min = max = number;
      total = 0;
      count = 0;
      while (number != -1) {
        if (number < min)
          min = number;
        if (number <= max)
          count++;
        total += number;
        if (number >= 90)
          A++;
        else if (number >= 80)
          B++;
        else if (number >= 70)
          C++;
        else if (number >= 60)
          D++;
        else
          F++;
        
        number = inputStream.nextInt();
      } // end while

      outputStream.println("Set " + sets + " of grades calculated");
      sets++;
      if (count == 0) {
        outputStream.println("no grades to average\n");
      } else {
        outputStream.println("There are a total of " + A + " A's");
        outputStream.println("There are a total of " + B + " B's");
        outputStream.println("There are a total of " + C + " C's");
        outputStream.println("There are a total of " + D + " D's");
        outputStream.println("There are a total of " + F + " F's");
        outputStream.println("The high score was " + max);
        outputStream.println("The lowest was " + min);
        avg = ((double) total) / ((double) count);
        outputStream.printf("The average score is: %.1f\n\n", avg);
      } // end else
    } // end while for each line
    System.out.println("Grade processing is completed");
    System.out.println("you can find output file at " + inOutFile);
    inputStream.close();
    outputStream.close();
    // close the inStream and outStream using the .close() for each
  }// end processFile()
}// end Grades class