
//import Scanner and/or JOptionPane
import java.util.Scanner;

/**
 * Prime numbers class does the following:
 * 1) Asks user for an integer to be checked as a prime number
 * 2) Uses a method to see if the number is divisible by 2
 * 3) Returns the user with is or Isn't a prime number
 * 4) Asks if the user would like to test another number
 * @author Adam Sanchez
 * @version v1.1
 * @since 10/6/22 (v1.1)
 */
public class Main { // Change to Main
  public static void main(String[] args) {
    // boolean var isPrime
    boolean isPrime;
    // int var number //original number to test
    int number;
    // String var playAgain //string to test to calc another number
    String playAgain;
    do{ //get program working first and then incorporate do while to play again
    // Display message to user, something like Enter a whole number>2 (ie 19) to
    // test if prime
    System.out.println("Enter a whole number>2 (ie 19) to test if prime:");
    // Create a Scanner object or JOptionPane to get user input and assign to number
    Scanner keyboard = new Scanner(System.in);
    number = keyboard.nextInt();
    // set isPrime to the result of testForPrime(number)
    isPrime = testForPrime(number);
    // if else to test if isPrimer. Display number and whether prime.
    if (isPrime) {
      System.out.println(number + " is a prime number");
    } else {
      System.out.println(number + " is not a prime number");
    }
    // Display message to test another number, something like Enter yes to test
      
      System.out.print("Would you like to test another number?");
      System.out.print(" Y or N: ");
    // another number, no to quit
    // set playAgain to user choice
      keyboard.nextLine();
      playAgain = keyboard.nextLine();
     } while (playAgain.equalsIgnoreCase("y"));//while to see if playAgain is String yes (recommend method that ignores
    // case
  }// end main

  /**
   * This method is used to check if the number inputed is prime
   * @param num - The number being tested to be a prime number
   * @return isPrimeMeth - a True or False boolean
   */
  // write header here for testForPrime. Can be public or private, but needs to be
  // static. Return type? Needs 1 param
  public static boolean testForPrime(int num) {
    // int var halfPlusOne //gets input from user, divides by 2 and adds1, this
    // shortens the testing and makes more effecient
    int halfPlusOne;
    // set halfPlusOne to param var/2+1;
    halfPlusOne = num / 2 + 1;
    // boolean var isPrimeMeth set to true, assumes number is prime
    boolean isPrimeMeth = true;
    for (int i = 2; isPrimeMeth && i <= halfPlusOne; i++) { // declare and set int var to 2
      // Can start here vs 1 for one less run
      // create an if to see if inNumber is divisible by i
      if (num % i == 0) {
        // if true set isPrimeMeth=?
        isPrimeMeth = false;
      } 
    }
    // return ?
    return isPrimeMeth;
  }// end testForPrime
}// end Prime