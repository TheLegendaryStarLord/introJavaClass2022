
//import Scanner
import java.util.Scanner;
import java.lang.Math;

/**
 * Falling Distance class does the following:
 * 1) Ask user input for number of seconds
 * 2) Create a simple chart to place values
 * 3) Calculate distance via seperate method with equation using gravity
 * 4) displays time and distance in chart in seconds and meters
 * 
 * @author Adam Sanchez
 * @version v1.1
 * @since 10/6/22 (V1.1)
 */
public class Main { // Change to Main
  // public constant for acceleration
  static final double Acceleration = 9.8;

  public static void main(String[] args) {
    // create Scanner object
    Scanner keyboard = new Scanner(System.in);
    // double var for distance
    double distance = 0.0;
    // int var for numOfSecs
    int numOfSecs;
    // Display Please enter how many seconds to compute:
    System.out.println("please enter how many seconds to compute: ");
    // get input from user for numOfSecs
    numOfSecs = keyboard.nextInt();
    // Display Time(secs) Distance(m) such that the output lines up nicely. Think
    // escape chars here (ie \t
    System.out.println("Time(secs)" + "\t" + "Distance(m)");
    // Possibly add ========= under Time and Distance, see Lab5 output example
    System.out.println("=========\t=========");
    // for loop that runs for each second
    for (double i = 0; i <= numOfSecs; i++) {
      // distance is assigned by getDistance() that passes current second from for
      // loop
      distance = getDistance(i);
      System.out.printf("%.0f\t\t\t%.2f\n", i , distance);
      // Display current second and distance with nice formatting (2 dec places for
      // distance). printf will work well here
    }
  } // end main

  /**
   * accepts double input of numOfSecs to calculate distance and returns it
   * 
   * @param sec - number of seconds to be used in equation
   * @return d - the distance from the calculations
   */
  public static double getDistance(double sec) {
    // the body just needs to be a single statement, a return that calculates
    // distance. See Lab5 for the formula
    double d;
    d = 0.5 * Acceleration * Math.pow(sec, 2);
    return d;
  }
}// end