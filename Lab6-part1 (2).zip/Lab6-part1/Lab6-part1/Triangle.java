import java.util.Scanner;
/**
 * Triangle class does the following:
 * 1) Connects to Main.java and grabs data for name, base, and name
 * 2) Does this for Triangle 1 and Triangle 2
 * 3) asks for user input to get name, base, and name and prints out data
 * 
 * @author Adam Sanchez
 * @version v1.1
 * @since 10/10/22 (v1.1)
 */
public class Triangle {
  private String name;
  private double base;
  private double height;
/**
 * Triangle() - Sets the Default name, base, and height
 */
  public Triangle() {
    name = "Unknown";
    base = 0.0;
    height = 0.0;
  }
/**
 * Triangle() - This one changes the data to the above Triangle()
 * @param name - Name of the Triangle
 * @param base - Base of the triangle
 * @param height - Height of the Triangle 
 */
  public Triangle(String name, double base, double height) {
    setName(name);
    setBase(base);
    setHeight(height);
  }
/**
 * writeOutput() - prints out the data of the triangle along with it's area
 */
  public void writeOutput() {
    System.out.println("Triangle's Name: " + name);
    System.out.println("Triangle's Base: " + base);
    System.out.println("Triangle's Height: " + height);
    System.out.printf("The Triangle's area is: %.1f\n", getArea());
  }
/**
 * readInput() - gets input from the user to put into the third triangle
 */
  public void readInput() {
    Scanner keyboard = new Scanner(System.in);
    System.out.println("What is this triangle's name?: ");
    name = keyboard.nextLine();
    System.out.println("What is this triangle's base?: ");
    base = keyboard.nextDouble();
    System.out.println("What is this triangle's height?: ");
    height = keyboard.nextDouble();
  }
/**
 * setName() - sets the name of the Triangle
 * 
 * @param newName - the new changed name of the triangle
 */
  public void setName(String newName) {
    this.name = newName;
  }
/**
 * setBase() - sets the base of the Triangle
 * 
 * @param newBase - the new changed base of the triangle
 */
  public void setBase(double newBase) {
    this.base = newBase;
  }
/**
 * setHeight() - sets the height of the Triangle
 * 
 * @param newHeight - the new changed height of the triangle
 */
  public void setHeight(double newHeight) {
    this.height = newHeight;
  }
/**
 * getArea() - gets the area of the triangle using an equation
 * 
 * @return Area via an equation
 */
  private double getArea() {
    return (base * height)/(2.0);
  }
}