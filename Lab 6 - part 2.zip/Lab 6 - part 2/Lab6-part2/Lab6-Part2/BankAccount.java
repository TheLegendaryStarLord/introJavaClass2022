/**
 * BankAccount class does the following:
 * 1) Connects to Main.java
 * 2) calculates values, and makes changes to balance with deposits and
 * withdrawals
 * 3) returns values when called
 * 
 * @author Adam Sanchez
 * @version v1.0
 * @since 10/13/22 (v1.0)
 */
public class BankAccount {
  private double balance;
  private double deposit;
  private double withdraw;
  private double interests;
  private double monthlyIntRate;

  /**
   * BankAccount() - The default data being used for monthlyIntRate and balance
   */
  public BankAccount() {
    monthlyIntRate = 0.035 / 12;
  }

  /**
   * BankAccount() - Input changes to bankaccount using console
   * 
   * @param inBalance - starting balance inputed by user
   * @param intRate   - used to calculate the monthlyIntRate
   */
  public BankAccount(double inBalance, double intRate) {
    monthlyIntRate = (intRate / 100) / 12;
    balance = inBalance;
  }

  /**
   * BankAccount() - Input changes to bankaccount using JOptionPane
   * 
   * @param inBalance - starting balance inputed by user
   * @param intRate   - used to calculate the monthlyIntRate
   */
  public BankAccount(String inBalance, String intRate) {
    monthlyIntRate = (Double.parseDouble(intRate) / 100) / 12;
    balance = Double.parseDouble(inBalance);
  }

  /**
   * makeDeposit() - adds the deposit amount to the balance
   * 
   * @param add - The amount of money being addded
   */
  public void makeDeposit(double add) {
    balance += add;
    deposit += add;
  }

  /**
   * makeDeposit() - adds the deposit amount to the balance
   * 
   * @param add - The amount of money being addded
   */
  public void makeDeposit(String add) {
    balance += Double.parseDouble(add);
    deposit += Double.parseDouble(add);
  }

  /**
   * makeWithdraw() - subtracts the withdraw amount from the balance
   * 
   * @param sub - the amount of money being subtracted
   */
  public void makeWithdraw(double sub) {
    balance -= sub;
    withdraw += sub;
  }

  /**
   * makeWithdraw() - subtracts the withdraw amount from the balance
   * 
   * @param sub - the amount of money being subtracted
   */
  public void makeWithdraw(String sub) {
    balance -= Double.parseDouble(sub);
    withdraw += Double.parseDouble(sub);
  }

  /**
   * calcInterest() - calculates the total interests
   */
  public void calcInterest() {
    if (balance > 0) {
      balance += (balance * monthlyIntRate);
      interests += (balance * monthlyIntRate);
    } else {
      interests = 0;
    }
  }

  /**
   * getBalance() - gets the current balance
   * 
   * @return balance
   */
  public double getBalance() {
    return balance;
  }

  /**
   * getDeposit() - gets the total amount of deposits
   * 
   * @return deposit
   */
  public double getDeposit() {
    return deposit;
  }

  /**
   * getWithdraw() - gets the total amount of withdrawals
   * 
   * @return withdraw
   */
  public double getWithdraw() {
    return withdraw;
  }

  /**
   * getInterest() - gets the total interest over months
   * 
   * @return interests
   */
  public double getInterest() {
    return interests;
  }

}