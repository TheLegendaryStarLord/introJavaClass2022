/** 
* This program prints out student information
* to the console
* @author Adam Sanchez, adam.sanchez54793@gcccd.edu 
* @since 9/3/2022 (Adam Sanchez, v1.0) 
* @version v1.0 
*/ 
public class Main {
  public static void main(String[] args) {

  System.out.println("ProChall3:\nStudent Information:\n Adam Sanchez" + "\n 1234 Sleep deprived Ave, San Diego, California, 99999" + "\n 888-999-1111" + "\nComputer Science Major");
  
  }
}