/** 
* This program prints the requested information
* for the Imprecisions assignment
* @author Adam Sanchez, adam.sanchez54793@gcccd.edu 
* @since 9/3/2022 (Adam Sanchez, v1.0) 
* @version v1.0 
*/ 
public class Imprecisions {
  public static void main(String[] args) {
    double x,y,z,value;
    x = 12345.6789E200 ;
    y = 1/x ;
    z= x*y ;
    value = 1 - z;
    
   System.out.println("Imprecision:\nThe value of x is: " + x + "\nThe value of y is: " + y + "\nThe value of z is: " + z + "\nThe value of 1-z is: " + value);
  }
}