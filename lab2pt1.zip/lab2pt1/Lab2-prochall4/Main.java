/** 
* This program prints out a diamond using
* stars in the output
* @author Adam Sanchez, adam.sanchez54793@gcccd.edu 
* @since 9/3/2022 (Adam Sanchez, v1.0) 
* @version v1.0 
*/ 
public class Main {
  public static void main(String[] args) {

  System.out.println("ProChall4:\n\t *" + "\n    ***" + "\n   *****" + "\n  *******" + "\n   *****" + "\n    ***" + "\n\t *");
  }
}