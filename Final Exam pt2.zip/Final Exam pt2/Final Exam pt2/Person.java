
/**
 * Person class that sets the name of the person
 *
 * @author Adam Sanchez
 * @version v1.0 (12/14/2022)
 */
public abstract class Person implements PersonInterface
{
    // instance variables - replace the example below with your own
    private String name;

    /**
     * default constructor for objects of class Person
     */
    public Person()
    {
        name = "TBD";
    }

    /**
     * Param Constructor for objects of class Person
     * @param inName - the input name of the person
     */
    public Person(String inName)
    {
        name = inName;
    }

    /**
     * setter for the name
     *
     * @param  inName - input name of the person
     * 
     */
    public void setName(String inName)
    {
        name = inName;
    }

    /**
     * getter for the name
     *
     * @return    the sum of x and y
     */
    public String getName()
    {
        return name;
    }

    /**
     * converts information into string
     *
     * @return    the sum of x and y
     */
    public String toString()
    {
        return name;
    }
}
