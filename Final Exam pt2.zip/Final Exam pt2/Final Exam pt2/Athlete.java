import java.util.Scanner;
import java.io.*;
import java.util.ArrayList;

/**
 * Athlete abstract class
 *
 * @author Adam Sanchez
 * @version v1.0 (12/14/2022)
 */
public class Athlete extends Person implements AthleteInterface
{
    // instance variables - replace the example below with your own
    private String eventName;
    private String inputFile;
    private String outputFile;
    public static final int ARRAY_SIZE = 4;

    /**
     * Constructor for objects of class Athlete
     */
    public Athlete()
    {
        super();
        eventName = "TBD";
    }

    /**
     * Constructor for objects of class Athlete
     */
    public Athlete(String inName, String inEventName)
    {
        super(inName);
        eventName = inEventName;
    }

    /**
     * setFileNames() – collects the location of the inputFile (athletes.csv) and output file and updates the 
    inputFile and outputFile instance vars.This method should ensure that the user inputs a valid file path for athletes.csv in a 
    while or do while loop. (10pts) 
     */
    public void setFileNames(){
        boolean inFileFound = true;
        boolean outFileFound = true;

        Scanner keyboard = new Scanner(System.in);

        do{
            System.out.println("Please enter the path to the entry file (c:/tmp/athletes.csv): ");
            String inInputFileTest = keyboard.nextLine();
            try{
                Scanner inFileTest = new Scanner(new File(inInputFileTest));
                //Scanner inFileTest = new Scanner(inInputFile);
                inFileFound = true;
                inFileTest.close();

            }
            catch(FileNotFoundException ex){
                System.out.println("File not found, please re-enter file path:");
            }

            inputFile = inInputFileTest;
        }while (inFileFound == false);

        do{
            System.out.println("Please enter the path to the output file (i.e c:/tmp/output.txt): ");
            String OutputFileTest = keyboard.nextLine();
            File outputFileTest = new File(OutputFileTest);
            if (outputFileTest.exists()){
                System.out.println("the file \"" + outputFileTest + "\" already exists");
                outFileFound = true;
            }
            else{
                outFileFound = false;
                outputFile = OutputFileTest;
                System.out.println("output file path set");
            }
        }while(outFileFound);
    }

    /**
     * csv2Array() – Creates an Athlete [ ] that has ARRAY_SIZE elements. Then reads in a csv file called 
    athletes.csv (via Scanner) whose path is set to inputFile instance field var.  An Athlete object should be 
    created for each line in Athletes.csv that sets name and event to the values in the csv file. (20pts) 
    athlete.csv is a two(2) column, four(4) row csv file that DOES NOT have a row header. 
    After processing all lines in the Athletes.csv, return the Athlete [ ] to the invoking method in the driver. 
    This method must try catch in the method body and not throws in the message header. 
    HINT – Scanner will throw a FileNotFoundException if the file is not found.   
    However, this should not happen since setFileNames( ) ensures a valid path, but the Java compiler still 
    requires a try catch or throws to compile
     */
    public Athlete[] csv2Array(){
        ArrayList<Athlete> convert = new ArrayList<Athlete>();

        File inFile = new File(inputFile);

        try(Scanner inputStream = new Scanner(inFile);){
            

            while (inputStream.hasNextLine()){
                String line = inputStream.nextLine();
                String[] arrayLine = line.split(",");

                Athlete athleteObject = new Athlete(arrayLine[0], arrayLine[1]);
                convert.add(athleteObject);
            }

            inputStream.close();
        }
        catch(FileNotFoundException ex){
            System.out.println("File not found, please re-enter file path:");
        }   
        Athlete[] list = new Athlete[ARRAY_SIZE];
        list = convert.toArray(list);

        return list;
    }

    /**
     * Setter for the event name
     */
    public void setEventName(String newEventName){
        eventName = newEventName;
    }

    /**
     * printArray2File(Athlete[] inArray, String inMsg) - writes inMsg, followed by output header, followed 
    by contents of Athlete[ ] produced in csv2Array to a text file (via PrintWriter) in nice columns (see 
    below for final output) (20pts).
    HINT – Use of “\t” for the header and the .toString( ), will help to line up your columns.
     */
    public void printArray2File(Athlete[] inArray, String inMsg) throws IOException{
        FileWriter outputWrite = null;
        PrintWriter outputPrint = null;

        try{
            outputWrite = new FileWriter(outputFile, true);
            outputPrint = new PrintWriter(outputWrite, true);
            outputPrint.println(inMsg + "\t");
            for(Athlete participant: inArray){
                outputPrint.println(participant);
            }
            outputPrint.println();
        }
        catch (IOException e){
            System.out.println("Error: file could not be written to");
        }
        finally{
            outputPrint.close();
            outputWrite.close();
        }
    }

    /** 
     * CompareTo to be used in sorting Athlete[]'s 
     * 
     * @param o Object that is passed to determine if it is less than,  
     * equal, or more than calling object. 
     * @return -1,0,1 
     */ 
    @Override 
    public int compareTo(Object o) { 
        if (o != null && this.getClass() == o.getClass()) { 
            Athlete temp = (Athlete) o; 
            return this.eventName.compareTo(temp.eventName); 
        } 
        return -1; 

    }

    /**
     * Displays information into String
     */
    public String toString(){
        return super.toString() + "\t" + eventName;
    }
}
