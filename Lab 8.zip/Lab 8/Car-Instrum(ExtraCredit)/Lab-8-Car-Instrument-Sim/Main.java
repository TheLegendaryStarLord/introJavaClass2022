import java.util.Scanner;

/**
 * Main does the following:
 * 1) uses user input to set the starting gas level
 * 2) creates a odometer object as the starting miles
 * 3) will continue to drive until gas is empty
 * 4) Does this for Car1 and Car2
 * 
 * @author Adam Sanchez
 * @version v1.0
 * @since 11/11/22 (v1.0)
 */

public class Main {
  public static void main(String[] args) {
    Scanner keyboard = new Scanner(System.in);

    System.out.print("Car1 gas level: ");
    int startingGas1 = keyboard.nextInt();

    FuelGauge fuelGauge1 = new FuelGauge(startingGas1);
    Odometer Car1 = new Odometer(1000, fuelGauge1);

    fuelGauge1.addGallons();
    System.out.println("Car1 gas level: " + fuelGauge1.getGallons());
    System.out.println("Car1 is off...\n" +
        "------------------");

    while (fuelGauge1.getGallons() > 0) {
      Car1.addMileage();
      System.out.println("Mileage:\t" + Car1.getMileage() + ", Fuel Level: " + fuelGauge1.getGallons());
      if (fuelGauge1.getGallons() == 0)
        System.out.println("You are out of gas!");
    }

    keyboard.nextLine();

    System.out.print("Car2 gas level: ");
    int startingGas2 = keyboard.nextInt();

    FuelGauge fuelGauge2 = new FuelGauge(startingGas2);
    Odometer Car2 = new Odometer(999850, fuelGauge2);

    fuelGauge2.addGallons();
    System.out.println("Car2 gas level: " + fuelGauge2.getGallons());
    System.out.println("Car2 is off...\n" +
        "------------------");

    while (fuelGauge2.getGallons() > 0) {
      Car2.addMileage();

      System.out.println("Mileage:\t" + Car2.getMileage() + ", Fuel Level: " + fuelGauge2.getGallons());

      if (fuelGauge2.getGallons() == 0)
        System.out.println("You are out of gas!");
    }

  }
}