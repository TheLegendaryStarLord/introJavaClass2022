/**
 * Odometer class does the following:
 * 1) sets up the odometer for the car
 * 2) Will add mileage as theres still gas
 * 3) will reset the mileage if it goes over the limit
 * 
 * @author Adam Sanchez
 * @version v1.0
 * @since 11/11/22 (v1.0)
 */

public class Odometer {

  final int maxMileage = 999999;
  final int MPG = 24;
  private int mileage, startingMileage, usedMileage;
  FuelGauge fuelgauge;

  /**
   * Odometer() - allows the odometer to be changed
   * @param mileage - the starting mileage
   * @param fuelgauge - the starting fuelgauge object
   */
  public Odometer(int mileage, FuelGauge fuelgauge) {
    this.mileage = mileage;
    this.startingMileage = mileage;
    this.fuelgauge = fuelgauge;
  }

  /**
   * Odometer() - copy of the Odometer
   * 
   * @param copy - copy of the odometer
   */
  public Odometer(Odometer copy) {
    mileage = copy.mileage;
    startingMileage = copy.mileage;
    fuelgauge = copy.fuelgauge;
  }

  /**
   * getMileage() - grabs the mileage in the odometer
   * 
   * @return mileage - current mileage
   */
  public int getMileage() {
    return mileage;
  }

  /**
   * addMileage() - adds mileage as the car continues driving
   */
  public void addMileage() {
    if (mileage <= maxMileage) {
      mileage++;
      usedMileage++;
    } else
      mileage = 0;

    if (usedMileage % MPG == 0) {
      fuelgauge.burnFuel();

    }
  }

}