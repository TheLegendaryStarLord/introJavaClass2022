/**
 * FuelGauge class does the following:
 * 1) sets up the fuel gauge for the car
 * 2) Will decrease gas based on mileage
 * 3) will add gas when called too
 * 
 * @author Adam Sanchez
 * @version v1.0
 * @since 11/11/22 (v1.0)
 */

public class FuelGauge {
  final int maxGallons = 15;
  private int gallons;

  /**
   * FuelGauge() - used to set the fuel gauge
   */
  public FuelGauge() {
  }

  /**
   * FuelGauge() - sets the starting gas in the tank
   * 
   * @param gallons - The gallons left in the gas tank
   */
  public FuelGauge(int gallons) {
    if (gallons <= maxGallons)
      this.gallons = gallons;
    else
      gallons = maxGallons;
  }

  /**
   * getGallons() - grabs the gallons in the tank
   * 
   * @return gallons - current gallons left in tank
   */
  public int getGallons() {
    return gallons;
  }

  /**
   * addGallons() - adss gas if its less than the max capacity
   */
  public void addGallons() {
    System.out.println("is filling up...");
    while (gallons < maxGallons) {
      if (gallons < maxGallons)
        gallons++;
      else
        System.out.println("The tank is full");
    }
  }

  /**
   * burnFuel() - will burn gas if there is still some left
   * 
   */
  public void burnFuel() {
    if (gallons > 0)
      gallons--;
    else
      System.out.println("The tank is empty");
  }
}