/**
 * RoomSize class does the following:
 * 1) Connects to Main.java and CarpetCost.java
 * 2) grabs information from Main.java
 * 3) send information to CarpetCost.java
 * @author Adam Sanchez
 * @version v1.0
 * @since 11/9/22 (v1.0)
 */

public class RoomSize {
  private String name;
  private double length;
  private double width;

  /**
   * RoomSize() - Input changes to Name and Show
   * 
   * @param inName - new name for room
   * @param inLen - the new length value
   * @param inWidth - new width value
   */
  public RoomSize(String inName, double inLen, double inWidth) {
    this.name = inName;
    this.length = inLen;
    this.width = inWidth;
  }

  /**
   * RoomSize() - copy of the RoomSize
   * @param copy - the copy of the original RoomSize
   */
  public RoomSize(RoomSize copy){
    name = copy.name;
    length = copy.length;
    width = copy.width;
  }

  /**
   * getArea() - Calculates the area of the room
   * @return Area - the calcululated area
   */
  public double getArea() {
    double Area;
    Area = length * width;
    return Area;
  }
  
  /**
   * toString() - Displays the information in string format
   * @return str - the information in string format
   */
  public String toString() {
    String str = "Name of Room: " + name + "\nLength of Room: " + length + "\nWidth of Room: " + width;
    return str;
  }
}