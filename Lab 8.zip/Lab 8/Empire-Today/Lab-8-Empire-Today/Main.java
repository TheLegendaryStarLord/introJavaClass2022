import java.util.Scanner;

/**
 * Main does the following:
 * 1) Connects to RoomSize.java and CarpetCost.java
 * 2) collects user information for name of room, area, and cost
 * 3) creates objects based on this information
 * 4) Displays the information with proper calculations
 * @author Adam Sanchez
 * @version v1.0
 * @since 11/9/22 (v1.0)
 */

public class Main {
  public static void main(String[] args) {
    String nameOf;
    double lengthOf;
    double widthOf;
    double cost;

    Scanner keyboard = new Scanner(System.in);

    System.out.print("Please enter the name of the Room: ");
    nameOf = keyboard.nextLine();

    System.out.print("Please enter the length of the Room: ");
    lengthOf = keyboard.nextDouble();

    System.out.print("Please enter the width of the Room: ");
    widthOf = keyboard.nextDouble();

    System.out.print("Please enter the cost per square feet: ");
    cost = keyboard.nextDouble();

    RoomSize temp = new RoomSize(nameOf, lengthOf, widthOf);
    CarpetCost masterRoom = new CarpetCost(temp, cost);

    System.out.println("\ninformation display\n" +
        "-----------------------\n"
        + masterRoom + "\n");

    keyboard.nextLine();

    System.out.print("Please enter the name of the Room: ");
    nameOf = keyboard.nextLine();

    System.out.print("Please enter the length of the Room: ");
    lengthOf = keyboard.nextDouble();

    System.out.print("Please enter the width of the Room: ");
    widthOf = keyboard.nextDouble();

    System.out.print("Please enter the cost per square feet: ");
    cost = keyboard.nextDouble();

    CarpetCost livingRoom = new CarpetCost(new RoomSize(nameOf, lengthOf, widthOf), cost);

    System.out.println("\ninformation display\n" +
        "-----------------------\n"
        + livingRoom);
  }
}