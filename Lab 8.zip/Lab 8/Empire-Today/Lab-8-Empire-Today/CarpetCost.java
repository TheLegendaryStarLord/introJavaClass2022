/**
 * CarpetCost class does the following:
 * 1) Connects to Main.java and RoomSize.java
 * 2) uses RoomSize.java to grab the size of the room
 * 3) Calculates the cost of the room
 * 4) Displays the information calculated
 * @author Adam Sanchez
 * @version v1.0
 * @since 11/9/22 (v1.0)
 */

public class CarpetCost {
  private RoomSize size;
  private double costPerSqFt;

  /**
   * CarpetCost() - calculates the cost of the rooms carpet
   * 
   * @param area - area of the room (RoomSize aggregation)
   * @param cost - the cost per square feet
   */
  public CarpetCost(RoomSize area, double cost) {
    this.size = area;
    this.costPerSqFt = cost;
  }

  /**
   * getCost() - used to grab the total cost by multiplying costPerSqFt by the area
   * @return costOf - the calcululated cost of the room carpet
   */
  public double getCost() {
    double costOf = costPerSqFt * size.getArea();
    return costOf;
  }

  /**
   * toString() - Used to display all information in string format
   * @return str - String Data holding the displayed information
   */
  public String toString() {
    String str = String.format(size.toString() +
        "\nCost per Sq Ft: " + costPerSqFt +
        "\nThe Total Cost is: %,.2f", getCost());
    return str;
  }

}