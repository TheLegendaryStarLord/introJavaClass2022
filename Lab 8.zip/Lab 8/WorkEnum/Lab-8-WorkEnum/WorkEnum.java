/**
 *  Weekdays
 *  @see MONDAY
 *  @see TUESDAY
 *  @see WEDNESDAY
 *  @see THURSDAY
 *  @see FRIDAY
 */

public enum WorkEnum{

  /**
     * MONDAY
     */
  MONDAY,
  /**
     * TUESDAY
     */
  TUESDAY,
  /**
     * WEDNESDAY
     */
  WEDNESDAY,
  /**
     * THURSDAY
     */
  THURSDAY,
  /**
     * FRIDAY
     */
  FRIDAY
}