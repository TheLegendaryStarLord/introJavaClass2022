/**
 * Main does the following:
 * 1) Creates a WorkWeek object using WorkEnum.java as a param
 * 2) compares values from two specified objects
 * 3) prints out the day assigned to the object using printDay()
 * @author Adam Sanchez
 * @version v1.0
 * @since 11/11/22 (v1.0)
 */
public class Main {
  public static void main(String[] args) {
    WorkWeek defConst = new WorkWeek();
    WorkWeek begin = new WorkWeek(WorkEnum.MONDAY);
    WorkWeek mid = new WorkWeek(WorkEnum.WEDNESDAY);

    defConst.daysAreSame(begin);
    defConst.daysAreSame(mid);
    
    defConst.compareDays(begin);
    begin.compareDays(mid);
    mid.compareDays(begin);

    mid.printDay();
  }
}