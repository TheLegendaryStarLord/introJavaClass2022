/**
 * WorkWeek class does the following:
 * 1) Grabs the Enum value from WorkEnum
 * 2) compares the values of objects from Main.java
 * 3) send information to CarpetCost.java
 * @author Adam Sanchez
 * @version v1.0
 * @since 11/11/22 (v1.0)
 */

public class WorkWeek {

  private WorkEnum day;

  /**
   * WorkWeek() - allows the day to be changed
   */
  public WorkWeek() {
    this.day = WorkEnum.MONDAY;
  } // set day to WorkEnum.MONDAY

  /**
   * WorkWeek() - allows the day to be changed
   * 
   * @param day - the new day being used to change
   */
  public WorkWeek(WorkEnum day) {
    this.day = day;
  } // can use this.day=day since day is an instance field

  /**
   * daysAreSame() - used to compare two values to check if they are the same
   * 
   * @param inWorkWeek - the secondary object being compared
   */
  public void daysAreSame(WorkWeek inWorkWeek) {
    if (inWorkWeek.getDay().equals(getDay()))
      System.out.println(getDay() + " is the same as " + inWorkWeek.getDay());
    else
      System.out.println(getDay() + " is not the same as " + inWorkWeek.getDay());
  }

  /**
   * compareDays() - compares two days to see which comes before the other
   * 
   * @param inWorkWeek - the secondary day being compared
   */
  public void compareDays(WorkWeek inWorkWeek) {
    if (getDay().ordinal() > inWorkWeek.getDay().ordinal())
      System.out.println(this.day + " comes after " + inWorkWeek.getDay());
    else if (getDay().equals(inWorkWeek.getDay()))
      System.out.println(getDay() + " is the same day as " + inWorkWeek.getDay());
    else if (getDay().ordinal() < inWorkWeek.getDay().ordinal())
      System.out.println(this.day + " comes before " + inWorkWeek.getDay());
  }

  /**
   * printDay() - prints the day
   * 
   */
  public void printDay() {
    System.out.println("The day is " + this.day);
  }
  /**
   * getDay() - gets the current day of the object
   * @return this.day - the current day of the object
   */
  public WorkEnum getDay() {
    return this.day;
  }
}
