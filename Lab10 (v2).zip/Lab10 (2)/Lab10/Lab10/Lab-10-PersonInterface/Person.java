
/**
 * used to set up the person
 *
 * @author Adam Sanchez
 * @version v1.0
 */
abstract class Person implements PersonInterface
{
    private String name;

    /**
     * person() - default name constructor
     */
    public Person(){
        name = "No name yet";
    }

    /**
     * person() - lets the name of the person be changed
     * @param name - name to be changed
     */
    public void person(String name){
        this.name = name;
    }

    /**
     * setName() - sets the name, updates the name
     * @param name - name to be updated
     */
    public void setName(String name){
        this.name = name;
    }

    /**
     * getName() - grabs the name of the person
     * @return name - name of the person
     */
    public String getName(){
        return name;
    }

    /**
     * toString() - converts information into a string
     * @return - information in string format
     */
    public String toString(){
        return "Name: " + name;
    } 
}
