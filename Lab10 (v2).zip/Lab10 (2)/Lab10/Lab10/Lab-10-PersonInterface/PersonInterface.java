
/**
 * Interface for the person class
 *
 * @author Adam Sanchez
 * @version V1.0
 */
interface PersonInterface
{
    // instance variables - replace the example below with your own
    int CURRENT_YEAR = 2022;

    /**
     * setName() - sets the name of the person
     * @param name - name to be set to person
     */
    void setName(String name);

    /**
     * getName() - gets the name of the person
     * @return String - the name in String
     */
    String getName();

    /**
     * toString()
     * @return String - puts the name into String format
     */
    String toString();
}
