
/**
 * marks the Employee as adjunct
 *
 * @author Adam Sanchez
 * @version v1.0
 */
public class Adjunct extends Employee
{
    private double hours;
    private double hrRate;

    public Adjunct(){
        hours = 0.0;
        hrRate = 0.0;
    }

    public Adjunct(double inHours, double inHrRate){
        hours = inHours;
        hrRate = inHrRate;
    }

    /**
     * setSalary() - sets the salary of the employee using hours and hour rate
     * @param inHours - input of the hours of the employee
     * @param inHrRate - amount being paid per hour
     */
    public void setSalary(double inHours, double inHrRate){
        hours = inHours;
        hrRate = inHrRate;
    }

    /**
     * toString() - converts information into a string
     * @return - information in string format
     */
    public String toString(){
        String strSalary = String.format("%,.2f",getSalary());
        return super.toString() + "Hours: " + hours + ", Hourly Rate: " + hrRate + ", Salary: $" + strSalary + "\n";
    }

    /**
     * getSalary() - gets the salary
     * @return - the salary using the hours and amount paid per hour
     */
    public double getSalary(){
        return hours * hrRate;
    }
}
