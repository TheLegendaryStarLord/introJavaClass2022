
/**
 * classes a person as an employee
 *
 * @author Adam Sanchez
 * @version V1.0
 */
public class Employee extends Person
{
    public final int CURRENT_YEAR = 2022;
    private int hireYear;
    private String idNum;

    /**
     * Employee() - default employee constructor
     */
    public Employee(){
        super();
        hireYear = 0;
        idNum = "OnBoarding";
    }

    /**
     * Employee() - lets the information be changed when first initialized
     * @param inName - the name being input
     * @param inHireYear - year of being hired input
     * @param inIdNum - Id number being input
     */
    public void Employee(String inName, int inHireYear, String inIdNum){
        setName(inName);
        hireYear = inHireYear;
        idNum = inIdNum;
    }

    /**
     * setIdNum() sets the Id number of the employee
     * @param inIdNum - Id number being input
     */
    public void setIdNum(String inIdNum){
    idNum = inIdNum;
    }
    
    /**
     * setHireYear() - sets the hire year to be updated
     * @param inHireYear - year of being hired input
     */
    public void setHireYear(int inHireYear){
    hireYear = inHireYear;
    }
    
    /**
     * equals() - checks to see if the two employees
     * @param o - the object being compared
     * @return - the boolean value
     */
    public boolean equals (Object o){ 
        boolean isEqual = false; 
        if (o != null && getClass()==o.getClass()){ 
            Employee copy = (Employee)o; 
            if (idNum.equalsIgnoreCase(copy.idNum)) 
                isEqual = true; 
        } 
        return isEqual; 
    } 

    /**
     * getServiceYears() - gets the service years
     * @return int - the amount of service years
     */
    public int getServiceYears(){
        return CURRENT_YEAR - hireYear;
    }

    /**
     * toString() - converts information into a string
     * @return - the string format of all information displayed
     */
    public String toString(){
        return super.toString() + "\nID number: " + idNum + "\nYear Hired: " + hireYear + ", Years of Service: " + getServiceYears() + "\n";

    }
}
