
/**
 * the Fulltime employee
 *
 * @author Adam Sanchez
 * @version 11/27/2022
 */
public class Fulltime extends Employee
{
    double salary;
    /**
     * 
     */
    public Fulltime(){
    salary = 0.0;
    }
    
    public Fulltime(double inSalary){
    salary = inSalary;
    }
    
    /**
     * toString() - displays all information in the string format
     * @return - the string format of the information
     */
    public String toString(){
        String strSalary = String.format("%,.2f",getSalary());
        return super.toString() + "Salary: $" + strSalary + "\n";
    }

    /**
     * setSalary() - sets the salary of the fulltime employee
     * @param inSalary - the inputed salary of the employee
     */
    public void setSalary(double inSalary){
        salary = inSalary;
    }

    /**
     * getSalary() - grabs the salary of the employee
     * @return salary - the salary of the employee
     */
    public double getSalary(){
        return salary;
    }
}
