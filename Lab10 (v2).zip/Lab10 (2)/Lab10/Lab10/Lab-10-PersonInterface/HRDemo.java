import java.util.ArrayList;
/**
 * Creates employees using inheritance and displays the uses of inheritance
 *
 * @author Adam Sanchez
 * @version v1.0 (11/27/2022)
 */
public class HRDemo
{
    public static void main(String[] args){

        Fulltime fred = new Fulltime(75000.1234);
        fred.Employee("Flinstone, Fred", 2013, "BR-1");
        //fred.setSalary(75000.1234);

        Adjunct barney = new Adjunct(320, 60.55);
        barney.Employee("Rubble, Barney", 2014, "BR-2");
        //barney.setSalary(320, 60.55);

        Fulltime wilma = new Fulltime();
        wilma.setName("Flinstone, Wilma");
        wilma.setIdNum("BR-3");
        wilma.setHireYear(2015);
        wilma.setSalary(78123.2468);

        Employee betty  = new Employee();
        betty.Employee("Rubble, Betty", 2017, "BR-4");

        Fulltime wilma2 = new Fulltime(78123.2468);
        wilma2.Employee("Slate, Wilma", 2015, "BR-3");
        //wilma2.setSalary(78123.2468);

        ArrayList<Employee> staff = new ArrayList<Employee>();
        staff.add(fred);
        staff.add(barney);
        staff.add(wilma);
        staff.add(betty);
        staff.add(wilma2);

        for (Employee people: staff){
            System.out.println(people);
        }

        System.out.println("==============================");
        
        System.out.println("wilma and wilma2 are the same: ");
        if (wilma.equals(wilma2)){
            System.out.print(wilma.equals(wilma2) + "\n");
            wilma.setName(wilma2.getName());
            staff.remove(4);
        }
        
        System.out.println("==============================");
        
        for (Employee people: staff){
            System.out.println(people);
        }
    }
}
