import java.util.Scanner;
/**
 * Main does the following:
 * 1) Asks the user for a password to be checked
 * 2) puts the password through a checker to see if its valid
 * 3) asks the user if they would like to check another password
 * @author Adam Sanchez
 * @version v1.0
 * @since 11/18/22 (v1.0)
 */
public class Main
{
    public static void main(String args[]){
        String input, redo;
        char ch;

        Scanner keyboard = new Scanner(System.in);

        do{
            System.out.println("Please Enter a Password to be cheked.");
            System.out.print("Valid Passwords are 8+ chars,have uppercase, lower case, and a number:");
            input = keyboard.nextLine();
            ch = input.charAt(0);
            passwordVerifier testing = new passwordVerifier(input);

            if(testing.testPassword() == true){
                System.out.println("Password is valid");
            }
            else{
                System.out.println("Password isn't valid");
            }

            testing = null;

            System.out.println("Would you like to continue? (type \"yes\")");
            redo = keyboard.nextLine();
        }while (redo.equalsIgnoreCase("yes"));
    }
}
