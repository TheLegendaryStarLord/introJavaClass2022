
/**
 * passwordVerifier does the following:
 * Is used to check a password to see if it meets all the requirements
 * 
 * @author Adam Sanchez
 * @version v1.0
 * @since 11/18/22 (v1.0)
 */

public class passwordVerifier
{
    private String password;

    /**
     * passwordVerifier() - used to set a new password to be checked
     * 
     * @param password - the password to be checked
     */
    public passwordVerifier(String password){
        this.password = password;
    }

    /**
     * testPassword() - puts the passowrd through a loop and checks each flag if one is met
     * @return isItGood - a flag that becomes true if all requirements are met
     */
    public boolean testPassword(){
        boolean isItGood = false;

        boolean hasLength = false;
        boolean hasLetter = false;
        boolean hasDigit = false;
        boolean hasLower = false;
        boolean hasUpper = false;

        if (password.length() >= 8){
            hasLength = true;
        }

        for(int letterTest = 0; letterTest < password.length(); letterTest++){
            if(Character.isLetter(password.charAt(letterTest))){
                hasLetter = true;

            }
            if(Character.isDigit(password.charAt(letterTest))){
                hasDigit = true;

            }
            if (Character.isLowerCase(password.charAt(letterTest))){
                hasLower = true;

            }
            if (Character.isUpperCase(password.charAt(letterTest))){
                hasUpper = true;

            }
            if (hasLength && hasLetter && hasDigit && hasLower && hasUpper){
                isItGood = true;
            }
        }

        return isItGood;
    }
}
