import java.util.ArrayList;
import java.io.File;
import java.util.Scanner;
import java.io.*;

/**
 * SalesAnalysis class does the following:
 * 1) grabs values from the file 
 * 2) puts values from string to double and puts into a new array
 * 3) sorts and displays values per week
 * 
 * @author Adam Sanchez
 * @version v1.0
 * @since 11/19/22 (v1.0)
 */
public class SalesAnalysis
{
    // instance variables - replace the example below with your own
    private ArrayList<Double> weeklyNumber = new ArrayList<Double>();
    private String inputFile;
    private final Integer DAYS_OF_WEEK = 7;

    /**
     * SalesAnalysis() - initializes the name of the file being input
     * 
     * @param inputFile - The name of the file being input
     */
    public SalesAnalysis(String inputFile){
        this.inputFile = inputFile;
    }

    /**
     * processFile() - opens the file and turns values into a string array
     * 
     */
    public void processFile()throws IOException{
        File file = new File(inputFile);
        Scanner inFile = new Scanner(file);

        while (inFile.hasNext()){
            String line = inFile.nextLine();
            String[] arrayLine = line.split(",");
            setArrayListElement(arrayLine);
        }

        inFile.close();
    }

    /**
     * setArrayListElement() - converts and totals inArray to 
     * 
     * @param inArray - the String array being converted
     */
    private void setArrayListElement(String[] inArray){
        double total = 0;
        for(String line : inArray){
            total += Double.parseDouble(line);
        }
        weeklyNumber.add(total);
    }

    /**
     * writeOutput() - prints out the calculated data
     */
    public void writeOutput(){
        double min, max, totalSales, dailySales, totalAvg;
        int minWeek, maxWeek;

        minWeek = maxWeek = 0;
        totalSales = dailySales = totalAvg= 0;
        min = max = weeklyNumber.get(0);

        for (int i = 0; i < weeklyNumber.size(); i++){
            if (weeklyNumber.get(i) < min){
                min = weeklyNumber.get(i);
                minWeek = i + 1;
            }
            if (weeklyNumber.get(i) > max){
                max = weeklyNumber.get(i);
                maxWeek = i + 1;
            }
            System.out.println("Week " + (i+1) + " Info");
            System.out.printf("Total Sales: " + "$%,.2f\n",weeklyNumber.get(i));
            dailySales = weeklyNumber.get(i) / DAYS_OF_WEEK;
            System.out.printf("Avg Daily Sales for Week: $%,.2f\n\n", dailySales );

            totalSales += weeklyNumber.get(i);
            totalAvg = totalSales / (i + 1);
        }
        System.out.printf("totalSales: $%,.2f\n",totalSales);
        System.out.printf("total avg: $%,.2f\n",totalAvg);
        System.out.println("Week " + maxWeek + " had the highest amount of sales");
        System.out.println("Week " + minWeek + " had the lowest amount of sales");
    }
}