import java.util.Scanner;
import java.io.*;
/**
 * Main class does the following:
 * 1) Asks the user to input the path towards the file to open
 * 2) checks if the file exists, and goes into a while loop if it does not exist
 * 3) Goes through a process that grabs values from that file
 * 4) Sorts values, and displays them
 * @author Adam Sanchez
 * @version v1.0
 * @since 11/19/22 (v1.0)
 */
public class Main
{
    public static void main(String [] args) throws IOException{
        Scanner keyboard = new Scanner(System.in);
        System.out.println("Enter the path to the SalesData.txt file: ");
        String inFileName = keyboard.nextLine();
        File file = new File(inFileName);
        
        while(!file.exists()){
            System.out.println("Enter the path to the SalesData.txt file: ");
            inFileName = keyboard.nextLine();
            file = new File(inFileName);
        }
        
        SalesAnalysis analysis = new SalesAnalysis(inFileName);
        analysis.processFile();
        analysis.writeOutput();
    }
}
