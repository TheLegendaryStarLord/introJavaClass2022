import java.util.Scanner;//Scanner
/**
 * ProChall12 class does the following:
 * 1) Request city name from user
 * 2) prints length of city name, prints name in lowercase, prints name in uppercase, and the first letter of the city name
 * @author Adam Sanchez, Adamsanchez625@gmail.com
 * @version v1.0
 * @since 9/6/2022 (v1.0)
 */
public class Main{  //change to Main.  Also, the Ch2 Ref Guide will be a BIG help
    public static void main (String[] args){
        String city;
        
        //Create a Scanner object
        Scanner keyboard = new Scanner(System.in);
        //Get input
        System.out.print("Enter a city: ");
      city = keyboard.nextLine();
        //city = Scanner object.next?? (NOTE you want to get the entire line)
        
        System.out.println("The city entered has: " + city.length() + " chars");
        System.out.println("In upper case: " + city.toUpperCase());
        System.out.println("In lower case: " + city.toLowerCase());
        System.out.println("First character: " + city.charAt(0));
    }
}