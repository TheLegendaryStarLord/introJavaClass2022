import java.util.Scanner;//Scanner
/**
 * ProChall13 class does the following:
 * 1) Calculate the tax to a meal
 * 2) Meal with tax
 * 3) Tip for a meal
 * 4) Meal with both tip and Tax
 * @author Adam Sanchez, adamsanchez625@gmail.com
 * @version v1.0
 * @since 9/6/2022
 */
public class Main
{  //change to Main.  Also, the Ch2 Ref Guide will be a BIG help
    public static void main (String[] args)
  {
        //double vars for meal, total, taxAmount, tipAmount
        double meal, total, taxAmount, tipAmount;
        final double TAX = 0.0675, TIP = 0.20;
        //create a double constant for TIP as well that is 20%
      
        //Create a Scanner object to get keyboard input
        Scanner keyboard = new Scanner (System.in);
        //Get input
        System.out.print("Enter meal amount: $");
        //assign meal var with a double from the Scanner object;
      meal = keyboard.nextDouble();
        //assign taxAmount var with a double from meal * ???
      taxAmount = meal * TAX;
        
        System.out.printf("\nThe tax is: $%,.2f", taxAmount);  //the $%,.2f is a place holder for $, then puts a , after three places and rounds to 2 decimal places
        total = meal + taxAmount; //need to add meal and tax together
        System.out.printf("\nThe meal cost with tax is: $%,.2f", total);
        tipAmount = total * TIP;//need to apply the TIP to the current total
        total = total + tipAmount; //Update total with tip amount.  Tip amount is based on total amount (meal and taxTotal)
        System.out.printf("\nThe tip is : $%,.2f", tipAmount);
        System.out.printf("\nThe meal cost with tip is: $%,.2f", total);
    }
}