import java.util.Scanner;//add the Scanner class here
/**
 * ProChall2 class does the following:
 * 1) Asks for user's name
 * 2) uses that data and finds the initial of your full name
 * 3) repeats the users name and initials
 * @author Adam Sanchez, adamsanchez625@gmail.com
 * @version v1.0
 * @since 9/6/2022 (Version 1.0)
 */
public class Main
{  //change to Main.  Also, the Ch2 Ref Guide will be a BIG help
    public static void main (String[] args)
  {
        //add three String vars (ie firstName, middleName, lastName)
    String firstname, middlename, lastname;
        //add three char vars (ie firstInit, middleInit, lastInit)
    char firstInit, middleInit, lastInit;
        
        //create a new Scanner object
        Scanner keyboard = new Scanner(System.in);
        //Get input
        System.out.print("Enter your first name: ");
    firstname = keyboard.nextLine();
        System.out.print("Enter your middle name: ");
    middlename = keyboard.nextLine();
        System.out.print("Enter your last name: ");
    lastname =  keyboard.nextLine();
        //firstName = ScannerObjectCreated.next??
        //Repeat the above for middleName and LastName
        
        //create initials
    firstInit = firstname.charAt(0);
    middleInit = middlename.charAt(0);
    lastInit = lastname.charAt(0);
        //firstInit = firstName.method to get a char at 0 index
        //Repeat above for middleInit and LastInit
        
        //Print Output
        System.out.println("\nMy name is: " + firstname + " " + middlename + " " + lastname);
        System.out.println("My initials are: " + firstInit + ", " + middleInit + ", and " + lastInit);
    }
}