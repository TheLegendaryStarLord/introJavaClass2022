import javax.swing.JOptionPane; //JOptionPane class
/**
 * ProChall15 class does the following:
 * 1) requests user input for number of shares and price for one
 * 2) Calculates the cost of total shares, commission, and both of the two together
 * 3) Shows the calculations to the user in window form
 * @author Adam Sanchez, Adamsanchez625@gmail.com
 * @version v1.0
 * @since 9/6/2022 (v1.0)
 */
public class Main
{  //change to Main.  Also, the Ch2 Ref Guide willbe a BIG help
    public static void main (String[] args)
  {
        //vars
        /*
        create a constant for COMM_RATE set to 2% 
        final double COMM_RATE = 0.02;
        String temp var
        double vars for total, pricePerShareDouble, commission, and totalCostShares
        int var for numShares
         */
    final double COMM_RATE = 0.02;
    double total, pricePerShareDouble, commission, totalCostShares;
    int numShares;
    String temp_var;
        //get input
        /*assign temp var using showInputDialog with message like "Enter number of 
shares purchased"
        Use Integer.parseInt with temp var as an argument to generate an int from 
String and assign to numShares
        Repeat these steps as appropriate to get pricePerShare
         */
    temp_var = JOptionPane.showInputDialog("Enter number of shares purchased");
    numShares = Integer.parseInt(temp_var);
    temp_var = JOptionPane.showInputDialog("Enter the Price of one share");
    pricePerShareDouble = Double.parseDouble(temp_var);
        //computations
        /*assign totalCostShares with product of what and what?
        assign commission with product of what (hint step above) and what?
        assign total with addition of what and what (hint look at above two values)
         */
    totalCostShares = numShares * pricePerShareDouble;
    commission = COMM_RATE * totalCostShares;
    total = commission + totalCostShares;
      //display output
    JOptionPane.showMessageDialog(null, String.format("Total cost of shares are: $%,.2f",totalCostShares) +
        String.format("\nCommission cost is: $%,.2f",commission) +
        String.format("\nTotal Cost is: $%,.2f",total));
        //make sure to add System.exit(0) :-)
      System.exit(0);
    
    }
}