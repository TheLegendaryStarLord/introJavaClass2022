import java.util.*;
import java.util.Scanner;
/**
 * class Rational - lets the user input integers to divide
 *
 * @author Adam Sanchez
 * @version v1.0
 */
public class Rational implements RationalInterface
{
    int numerator;
    int denom;
    double result;

    /**
     * Rational() - default constructor
     */
    Rational(){
        numerator = 0;
        denom = 0;
        result = 0.0;
    }

    /**
     * doRational() - main method to input information
     * @throws InputMismatchException - thrown if input is not int
     * @throws DivideByZeroException - thrown if denominator is zero
     */
    public void doRational() throws InputMismatchException, DivideByZeroException{
        Scanner keyboard = new Scanner(System.in);
        boolean optMade = false;

        do{

            System.out.println("Enter an int (whole number) for the numerator (ie 3): ");
            numerator = setUserInput();
            System.out.println("Enter an int (whole number) for the denominator, but don't enter 0: ");
            denom = setUserInput();
            result = calcRational();
            System.out.printf("With the numerator " + numerator + " and denominator " + denom + ", the result is %,.3f \n",result);

            System.out.println("Enter Y to continue, or N to end: ");
            String option = keyboard.nextLine(); 

            do{               
                if (option.equalsIgnoreCase("Y")){
                    System.out.println("You pressed Y");
                    optMade = true;
                }
                else if(option.equalsIgnoreCase("N")){
                    System.out.println("You pressed N");
                    optMade = false;
                }
                else{
                    System.out.println("Invalid Option; Please enter Y/N:");
                    option = keyboard.nextLine();
                }
            }while(!(option.equalsIgnoreCase("y") || option.equalsIgnoreCase("n")));
        }while(optMade == true);
    }

    /**
     * setUserInput() - input information for int
     * @throws InputMismatchException - thrown if input is not int
     */
    public int setUserInput() throws InputMismatchException{
        Scanner keyboard = new Scanner(System.in);
        int setInt = keyboard.nextInt();
        return setInt;
    }

    /**
     * calcRational() - calculates division of two int
     * @throws DivideByZeroException - thrown if denominator is zero
     */
    public double calcRational() throws DivideByZeroException{
        if (denom == 0){
            throw new DivideByZeroException("You cannot divide by zero");
        }
        double calc = (double) numerator / denom;
        return calc;
    }
}
