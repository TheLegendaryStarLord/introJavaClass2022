
/**
 * used when the denominator is zero
 *
 * @author Adam Sanchez
 * @version v1.0
 */
public class DivideByZeroException extends Exception
{
    /**
     * DivideByZeroException() - default constructor
     */
    public DivideByZeroException(){
        super("DivideByZeroException");
    }

    /**
     * DivideByZeroException() - constructor + string message
     * @param message - the string param
     */
    public DivideByZeroException(String message){
        super(message + ": DivideByZeroException");
    }
}
