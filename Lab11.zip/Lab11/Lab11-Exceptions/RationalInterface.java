import java.util.*;
/**
 * interface for the rational
 *
 * @author Adam Sanchez
 * @version v1.0
 */
public interface RationalInterface
{
    /**
     * doRational() - main method to input information
     * @throws InputMismatchException - thrown if input is not int
     * @throws DivideByZeroException - thrown if denominator is zero
     */
    void doRational() throws InputMismatchException, DivideByZeroException;
    /**
     * setUserInput() - input information for int
     * @throws InputMismatchException - thrown if input is not int
     */
    int setUserInput() throws InputMismatchException;
    /**
     * calcRational() - calculates division of two int
     * @throws DivideByZeroException - thrown if denominator is zero
     */
    double calcRational() throws DivideByZeroException;
}
