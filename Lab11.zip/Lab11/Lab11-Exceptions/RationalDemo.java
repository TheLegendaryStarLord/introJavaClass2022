import java.util.*;
/**
 * uses two integers to divide and asks to do it again
 *
 * @author Adam Sanchez
 * @version v1.0
 */
public class RationalDemo
{
    public static void main(String[] args) {
        Rational rat1 = new Rational();

        try{
            rat1.doRational();
        }
        catch(InputMismatchException IM_ex){
            System.out.println("try running the program again, this time use integers for num and denom");
        }
        catch(DivideByZeroException DVB_ex){
            System.out.println("Error: " + DVB_ex.getMessage());
        }
        finally{
            System.out.println("Thanks for using RationalDemo, CU soon");
            System.exit(0);
        }
    }
}
