import java.util.Scanner;

/**
 * Temperature class does the following:
 * 1) asks the user for a tempurature followed by a unit, "C" or "F"
 * 2) converts the temp, C -> F, F -> C
 * 3) shows the user the converted temp
 * 4) asks the user if they would like to convert another temp
 * @author Adam Sanchez
 * @version v1.0
 * @since 9/21/2022 (V1.0)
 */
public class Main { // Change to Main for Replit
  public static void main (String[] args){
        ////vars section
        //create vars for inputTemp, output (num with decimal), and char inputUnit
      String input;
      double inputTemp, newtemp;
      char inputUnit;
        //Scanner object to read in keyboard
      Scanner keyboard = new Scanner(System.in);
        do{  ////create working program and then put in do-while
          
            //Enter msg to user something like, Enter a whole number, a space, 
            //  and C or F (ie 100 F converts to Cels");
          System.out.print("Enter a whole number spaced with a C or F, I.E '100 F'");
            //get inputTemp
          inputTemp = keyboard.nextDouble();
            //get inputUnit, recommend forcing toUpperCase or toLowerCase
          inputUnit = keyboard.next().toUpperCase().charAt(0);

            //  before getting char.  This will make the while pit easier :-)
            ////while loop pit.  You want a 'C' OR 'F', if a user enters this
            ////you want to keep them out.  So how do you do the opposite?
            ////How about using !
            ////If a user is in the while pit, tell them want you want to get
            ////them out by entering 'C' OR 'F'.  Grab the char, just like above
            ////before the while pit. 
          while (!(inputUnit == 'F' || inputUnit == 'C')){
            System.out.println("Please enter a 'C' or a 'F'");
            inputUnit = keyboard.next().toUpperCase().charAt(0);
          }
            //if inputUnit is 'F'  ////remember a primitive type therefore use ==
          if (inputUnit == 'F'){
            ////compute output (F->C).  Assuming you collected an int from the user, you will need
            ////to cast part of the equation as a double or using a double in the equation (ie 5.0).
            ////then nicely format (think printf here) the output to one decimal place.  
            ////%d is for int, %c is for char, %f along with precision for double
            newtemp = (inputTemp - 32) * (5.0/9.0);
            System.out.printf("%.1f converted is %.1f C. ", inputTemp, newtemp);
          }
          else{
            //  compute output (C->F).  You know at this point the only other possible char is 'C'
            ////You will need to cast part of the equation as a double or use a double (ie 5.0).
            ////then nicely format (think printf here) the output to one decimal place.  
            ////%d is for int, %c is for char, %f along with precision for double
            newtemp = (inputTemp * (9.0/5.0)) + 32;
            System.out.printf("%.1f converted is %.1f F. \n", inputTemp, newtemp);
          }
          
            //Now you can will need to collect input for the do-while part
          System.out.print("");
          System.out.println("would you like to convert" + " another temp?");
          System.out.print("Please enter Y or N: \n");
          keyboard.nextLine();
          input = keyboard.nextLine();
          
          
            //Message to user to enter yes to calculate another temp.
          
        }while (input.equalsIgnoreCase("y")); //while can either use the String collected with equalsIgnoreCase("yes") or force 
        //      toUpperCase/toLowerCase and then grab charAt(0) and have the while evaluate to == 'Y' (or 'y')
    }//// end main ()
}//// end class