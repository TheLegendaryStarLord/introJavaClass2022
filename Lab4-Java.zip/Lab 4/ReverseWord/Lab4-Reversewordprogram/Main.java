import java.util.Scanner;

/**
 * ReverseWord class does the following:
 * 1) will ask the user for a set of words followed by quit
 * 2) the program will move the letter to the end of the word and reverse it
 * 3) then it will check to see if the new word equals the original word
 * 4) Finally, it will let you know if works or not
 * 5) Then ask if the user would like to check another set of words followed by quit
 * @author Adam Sanchez
 * @version v1.0
 * @since 9/24/2022 (V1.0)
 */
public class Main { // Change to Main for Replit
  public static void main(String[] args) {
    //// vars section
    String word, remaining, flipped, input, reverse;
    char firstLetter;
    Scanner keyboard = new Scanner(System.in);

    do {
      System.out.println("Enter your list of words followed by ''quit''");
      word = keyboard.next().toLowerCase();
      while (!(word.equalsIgnoreCase("quit"))) {

        firstLetter = word.charAt(0);
        remaining = word.substring(1);
        flipped = remaining + firstLetter;
        reverse = "";

        for (int i = flipped.length() - 1; i >= 0; i--) {
          reverse += flipped.charAt(i);

        }
        if (word.equals(reverse))
          System.out.print(word + " works\n");
        else
          System.out.print(word + " does not work\n");

        word = keyboard.next().toLowerCase();

      }
      System.out.println("would you like to check" + " another set of words?");
      System.out.print("Please enter Y or N: \n");
      keyboard.nextLine();
      input = keyboard.nextLine();
    } while (input.equalsIgnoreCase("y"));
  }
}