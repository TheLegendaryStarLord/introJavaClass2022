//import class to generate random numbers
import java.util.Random;
/**
 * BarChartMethods class does the following:
 * 1) Generate a random set number
 * 2) the program will first print a random set of number
 * 3)  using a seperate method the program will print a star for every 100
 * @author Adam Sanchez
 * @version V1.0
 * @since 9/24/2022 (V1.0)
 */
public class Main{ //Change to Main for Replit
    public static void main (String[] args) {
        ////vars section
        //int vars for first, second, third
      int first, second, third;
        ////generate and assign random numbers section
        //Create a Random object (ie generator)
      Random randomNumbers = new Random();
        //Use generator to create a random number btw 0 and 999 and assign to first.  Do the same for second and third
      first = randomNumbers.nextInt(1000);
      second = randomNumbers.nextInt(1000);
      third = randomNumbers.nextInt(1000);
        ////Print out numbers
        //Message to print out something like, Number 1 is: XXX. Do the same for Number 2 and 3
      System.out.println("Number 1 is " + first);
      System.out.println("Number 2 is " + second);
      System.out.println("Number 3 is " + third);
        //Print blank line
      System.out.print("\n");
        ////Bar Chart Section
        //Print out NUMBER BAR CHART as a header
    System.out.println("NUMBER BAR CHART");
        ////first stars
        //Print out "Number 1: " without a line break
      System.out.print("Number 1: ");
        //printStars(first);
      printStars(first);
        ////second stars
        //Print out "Number 2: " without a line break
      System.out.print("Number 2: ");
        //printStars(second);
        printStars(second);
        ////third stars
        //Print out "Number 3: " without a line break
      System.out.print("Number 3: ");
        //printStars(third);
      printStars(third);
    }////end main()
    /**
     * Accepts int input and prints stars
     * @param input - number of stars to print out
     */
    public static void printStars(int input){
        if (input<100)
            //Print, <100 no stars
          System.out.print("<100 no stars");
        else
            //for loop that prints out stars for each 100 (ie 356 prints out 3 stars).  Take advantage of integer division here (input/100)
          for(int i = 1; i <= input/100; i++){
                //Print a *, HINT-The stars should be horizontal (on 1 line) for each number.
            System.out.print("*");
          }
        //Print line to get to a new line
      System.out.println("\n");
    
    }////end printStars()
}////end Grades