import java.util.Scanner;
import java.util.Random;

/**
 * ValidDate asks the user to input a date in
 * 1) the program wil then go through 'if' and case statments to validate the date
 * 2) days are sorted by 'if', months by case statments
 * @author Adam Sanchez
 * @version v1.0
 * @since 9/17/2022 (v1.0) 
 */
public class Main {
  public static void main(String[] args) {
    int month, day, year;
    String temp, output;
    Scanner keyboard = new Scanner(System.in);
    keyboard.useDelimiter("/");
    output = "";
    System.out.print("Please enter a date in mm/dd/yyyy format: ");
    month = keyboard.nextInt();
    day = keyboard.nextInt();
    temp = keyboard.nextLine().substring(1);
    year = Integer.parseInt(temp);
    boolean isValid = false;
    //// Create if-else if to look for when:
    //// Section 1, day is less than 1
    if (day < 1)
      output = "Invalid day, never less than a day in a month";

    //// Section 2, day is larger than 31
    else if (day > 31)
      output = "Invalid day, never more than 31 days in a month";
    //// Section 3, btw 1 and 31 days, can use a switch that evaluates
    //// to month with intentional bleed through
    else {
      switch (month) {
        //// Cases for all 31 day months
        case 1:
        case 3:
        case 5:
        case 7:
        case 8:
        case 10:
        case 12:
          isValid = true;
          break;
        //// Cases for all 30 day months
        case 4:
        case 6:
        case 9:
        case 11:
          if (day <= 30)
            isValid = true;
          else
            output = "Can not have 31 days in this month";
          break;
        //// This is February
        case 2:
          boolean isLeapYear = false;
          if (year % 400 == 0 || (year % 4 == 0 && (year % 100 != 0)))
            //// Carefully look at || and && combo
            isLeapYear = true;
          if (isLeapYear) {
            if (day <= 29)
              isValid = true;
            else
              output = "Cannot have more than 30 days in a leap year";
          } else { //// non-leap year
            if (day <= 28)
              isValid = true;
            else
              output = "cannot have more than 29 days";
          }

          break;
        default:
          output = "Months must be between 1-12";
      }//// End of switch
    } //// End of else section for multibranch if-else if

    //// Output section
    if (isValid) //// if isValid is true statement below will run

      System.out.println(month + "/" + day + "/" + year + " is a valid date");
    else
      System.out.println(month + "/" + day + "/" + year + " is not a valid date" + output);
  }//// end main
}
//// end class