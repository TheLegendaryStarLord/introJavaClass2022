
import java.util.Scanner;

/**
 * Sorting asks the user to ...
 * 1) input 3 numbers into the console
 * 2) then the program will sort the program using multiple if statements
 * 3) the program will then say the order of numbers from smallest to largest
 * @author Adam Sanchez
 * @version v1.0
 * @since 9/13/2022 (v1.0)
 */
public class Main // Replit change to Main
{
  public static void main(String[] args) {
    // vars
    // ints for each number and ints low, med, high
    int n1, n2, n3, low, med, high;

    // Create a Scanner object, create an input message, and collect 3 numbers to be
    // sorted
    Scanner keyboard = new Scanner(System.in);
    System.out.print("enter three numbers to be sorted starting with the first number: ");
    n1 = keyboard.nextInt();

    System.out.print("Now the second number: ");
    n2 = keyboard.nextInt();

    System.out.print("And finally the last number: ");
    n3 = keyboard.nextInt();

    // Look for when n1 is smallest section
    if ((n1 <= n2) && (n1 <= n3)) {
      // we can set n1 to low
      low = n1;
      // Now figure out if n2 is smaller or equal to n3,
      if (n2 <= n3) {
        med = n2;
        high = n3;
      } else {
        med = n3;
        high = n2;
      }
      // if true n2 is ?, n3 is ?
      // else n2 is ?, n3 is ?
    }
    // Above n1 is smallest, now we need to figure out when n2 is smallest section
    else if (n2 <= n3) { // n2 is smallest
      low = n2;
      if (n1 <= n3) {
        med = n1;
        high = n3;
      } else {
        med = n3;
        high = n1;
      }
      // we can set n2 to low
      // Now figure out if n1 is smaller or equal to n3,
      // if true n1 is ?, n3 is ?
      // else n1 is ?, n3 is ?
    }
    // Above are n1 and n2 smallest sections. Therefore, by default (else) this
    // is n3 is smallest section
    else { // n3 is smallest
      // we can set n3 to low
      low = n3;
      if (n1 <= n2) {
        med = n1;
        high = n2;
      } else {
        med = n2;
        high = n1;
      }
      // Now figure out if n1 is smaller or equal to n2,
      // if true n1 is ?, n2 is ?
      // else n1 is ?, n2 is ?
    }
    // Message that says - The inputs sorted smallest to largest are: <low> <med>
    System.out.print("Going from smallest to largest, the order is : " + low + " " + med + " " + high);
    // <high>
  }// end main
}// end class