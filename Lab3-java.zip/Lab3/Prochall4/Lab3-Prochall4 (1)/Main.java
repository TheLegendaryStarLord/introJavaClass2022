import javax.swing.JOptionPane;

/**
 * ProbChall_4 asks the user to input their scores for three 3
 * 1) The program will then find the average for all 3 exams
 * 2) The program will then give a grade for the appropriate score average
 * 
 * @author Adam Sanchez
 * @version v1.0
 * @since 9/17/2022 (v1.0)
 */
public class Main // Replit change to Main
{
  public static void main(String[] args) {
    // vars
    String str;
    // int vars for each exam
    int exam1, exam2, exam3;
    // double var for avg
    double avg;
    // char var for grade
    char grade;
    // get user input for each exam via GUI, will need to get a String and use
    // Integer wrapper class to convert
    str = JOptionPane.showInputDialog("Please enter your score " + "for exam 1");
    exam1 = Integer.parseInt(str);
    str = JOptionPane.showInputDialog("Please enter your score " + "for exam 2");
    exam2 = Integer.parseInt(str);
    str = JOptionPane.showInputDialog("Please enter your score " + "for exam 3");
    exam3 = Integer.parseInt(str);
    // figure out average, make sure you generate a double. Think casting here.
    avg = (double)(exam1 + exam2 + exam3) / 3;
    // Create Multibrach if-else if based on scores that sets appropriate
    // lettergrade (char)
    if (avg >= 90) {
      grade = 'A';

    } else if (avg >= 80 && avg < 90) {
      grade = 'B';

    } else if (avg >= 70 && avg < 80) {
      grade = 'C';

    } else if (avg >= 60 && avg < 70) {
      grade = 'D';

    } else {
      grade = 'F';

    }
    // GUI output
    // showMessageDialog with message and formatting so that average is 1 decimal
    // place and
    // on next line provides the letter grade
    JOptionPane.showMessageDialog(null,
                                  String.format("With an average score of %.1f \n Your grade is " + grade, avg));
    // make sure to include a proper System.exit to close the GUI thread
    System.exit();
  }// end main
}// end class