import java.util.Scanner;
/**
 * ProbChall_1 asks the user for a number
 * 1) The program will then reply via cases
 * 2) if the number corresponds with a valid case number
 * then the program will use the message set for that response
 * 3) If the number used isn't set with a valid case
 * then the program will respond with a message informing the user of the invalid option
 * @author Adam Sanchez, Adamsanchez625@gmail.com
 * @version v1.0
 * @since 9/17/2022 (v1.0)
 */
public class Main
  {
    public static void main (String[] args)
    {
        //create an int to be used for the switch
      int forswitch;
        //Create a Scanner object tied to the keyboard
      Scanner keyboard = new Scanner(System.in);
        //Message to the user, what do you want them to enter
      System.out.print("Please enter a number from 1-3 to see the roman numeral associated for it: ");
        //Use Scanner object to assign value to int created in 14 above
      forswitch = keyboard.nextInt();
        
        //switch statement
        switch(forswitch)
        {
          case 1:
            //Message to user saying # converted to Roman Numeral is ?
            System.out.println("The roman numeral equivalent of 1 is I");
            //If you don't have this, you will bleed through to other cases
              break;
            //Repeat for cases 2&3
          case 2:
            System.out.println("The roman numeral equivalent of 2 is II");
            break;
          case 3:
            System.out.println("The roman numeral equivalent of 3 is III");
              break;
          default:
            System.out.println("The number " + forswitch + " is not a valid option, The number must be between 1-3");
            break;
            //What can you use as a catch all if the user does not enter a number from 1->3
            //Message to user indicating <input-what was entered> + was not not a valid number, must be btw 1->3
            //Not that you need this here since you will not be able to bleed thru,but it is considered proper
        }
    }
}